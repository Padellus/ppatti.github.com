
public class SchemeNumber extends SchemeObject{
	
	public int n;
	
	public SchemeNumber(int number)
	{
		n=number;
	}
	public SchemeObject eval(AVLTree env)
	{
		return this;
	}

	public void print() {
		System.out.print(n);
	}
}
