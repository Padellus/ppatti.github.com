import java.io.*;

public class Parser {

	private Stack data;
	private Tokenizer input;

	public Parser(Tokenizer input) {
		this.input = input;
		this.data = new Stack();
	}

	// Gets the next SchemeObject using Shift-Reduce on stream input.
	// It will continue requesting input until the stack reduces to just
	// one SchemeObject element.	
	public SchemeObject nextObject() throws IOException {
		while(true) {
			while (PatternMatch()) { /* Do nothing */ }
			
			if(data.length() == 1 && data.peek(0) instanceof SchemeObject)
				return (SchemeObject) data.pop();

			data.push(input.nextToken());
		}
	}

	private boolean PatternMatch() {
		if (data.peek(0) instanceof TokenSymbol){
			// Rule 1:
			// Before: TokenSymbol(val)
			// After:  SchemeSymbol(val)

			TokenSymbol top = (TokenSymbol)data.pop();
			SchemeSymbol newSS = new SchemeSymbol(top.getValue());

			data.push(newSS);
			
			return true;
		}
		else if (data.peek(0) instanceof CloseParen && data.peek(1) instanceof SchemeObject &&
			data.peek(2) instanceof Period && data.peek(3) instanceof SchemeObject) {
			// Rule 2:
			// Before: SchemeObject a, Period, SchemeObject b, CloseParen
			// After:  Period, SchemePair(a,b), CloseParen

			CloseParen c = (CloseParen) data.pop();
			SchemeObject b = (SchemeObject) data.pop();
			Period p = (Period) data.pop();
			SchemeObject a = (SchemeObject) data.pop();

			SchemePair sp = new SchemePair(a,b);
			
			data.push(p);
			data.push(sp);
			data.push(c);

			return true;
		} 
		else if(data.peek(0) instanceof CloseParen && data.peek(1) instanceof SchemeObject &&
			data.peek(2) instanceof Period && data.peek(3) instanceof OpenParen) {
			// Rule 3:
			// Before: OpenParen, Period, SchemeObject, CloseParen
			// After:  SchemeObject

			data.pop();
			SchemeObject obj = (SchemeObject) data.pop();
			data.pop();
			data.pop();

			data.push(obj);
			
			return true;
		}
		else if(data.peek(2) instanceof Period && data.peek(3) instanceof Period) {
			// Special Rule:
			// Before: Period, Period, Object, Object
			// After:  Empty stack + Error output

			// If [Period, Period] occurs in the stack, the stack will never reduce.

			while (data.length() > 0)
				data.pop();
	
			System.out.println("Invalid input.");
			
			return true;
		}
		else if(data.peek(0) instanceof Period && data.length() == 1) {
			// Special Rule:
			// Before: Period is only item on stack
			// After:  Empty stack + Error output

			// Another case in which the stack will never reduce.

			data.pop();
	
			System.out.println("Invalid input.");
			
			return true;
		}
		else if(data.peek(0) instanceof CloseParen) {
			// Rule 4:
			// Before: CloseParen
			// After:  Period, SchemeNull, CloseParen

			CloseParen c = (CloseParen) data.pop();
			
			data.push(new Period());
			data.push(new SchemeNull());
			data.push(c);

			return true;
		} 

		return false;
	}
}
