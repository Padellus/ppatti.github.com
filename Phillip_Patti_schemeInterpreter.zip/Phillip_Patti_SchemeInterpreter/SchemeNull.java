

public class SchemeNull extends SchemeObject {

	//
	public SchemeObject eval(AVLTree t)
	{
		return this;
	}
	//
	
	public void print() {
		System.out.print("()");
	}
}
