

public class Stack {

	private StackNode top;
	private int length;

	public Stack() {
		top = null;
	}
	
	public void push(Object o) {
		StackNode newNode = new StackNode(o,top);
		top = newNode;
		length++;
	}
	
	public Object pop() {
		if(top != null) {
			Object output = top.data;
			top = top.next;
			length--;
			return output;
		}
		
		return null;
	}
	
	public Object peek(int index) {
		StackNode node = top;
		
		if (index < 0 || index >= length)
			return null;

		for (int i = 0; i < index && node != null; i++) {
			node = node.next;
		}
		
		return node.data;
	}

	public int length() {
		return this.length;
	}
}
