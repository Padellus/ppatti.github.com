public class AVLTree {

	tNode root;
	public class tNode
	{
		public Pair pair;
		public tNode left;
		public tNode right;
		public int height;
		public boolean deleted;
		public tNode(Pair p, tNode l, tNode r)
		{pair = p; left = l; right = r; height = 0; deleted=false;} 
	}

	public AVLTree()
	{
		root = null;
	}

	public void add(Pair p)
	{
		if(root==null)
		{
			root = new tNode(p, null, null);
		}
		else
		{
			root=addhelper( root, p);
		}
	}
	public tNode addhelper(tNode t, Pair p)
	{
		if(t == null)
		{
			return new tNode( p, null, null);
		}
		else
		{
			if(p.key.compareTo(t.pair.key) > 0) // greater than key
			{
				t.right = addhelper(t.right, p);
				t.height++;
			}
			else if(p.key.compareTo(t.pair.key) == 0) // equal
			{
				t.deleted=false;
				return t;
			}
			else
			{
				t.left = addhelper(t.left, p);
				t.height++;
			}}

		int leftheight = 0;
		int rightheight = 0;
		if (t.left==null)
		{ leftheight = -1; }
		else {leftheight = t.left.height;}
		if (t.right==null)
		{ rightheight = -1; }
		else {rightheight = t.right.height;}
		
		if(leftheight>rightheight)
		{ t.height = leftheight+1;}
		else
		{ t.height = rightheight+1;}

		if((leftheight - rightheight) > 1) // Left imba
		{
			if(t.left.left == null) // Left Right
			{
				t.left= rotateLeft(t.left);
				t= rotateRight(t);
			}
			else if(t.left.right == null) // Left Left
			{
				t= rotateRight(t);
			}
			else if(t.left.left.height > t.left.right.height) // Left Left
			{
				t= rotateRight(t);
			}
			else // Left Right
			{
				t.left= rotateLeft(t.left);
				t= rotateRight(t);
			}
		}
		else if((rightheight - leftheight) > 1) // Right imba
		{
			if(t.right.right == null) // Right Left
			{
				t.right = rotateRight(t.right);
				t= rotateLeft(t);
			}
			else if(t.right.left == null) //  Right Right
			{
				t= rotateLeft(t);
			}
			else if(t.right.right.height > t.right.left.height) // Right Right
			{
				t= rotateLeft(t);
			}
			else // Right Left
			{
				t.right = rotateRight(t.right);
				t= rotateLeft(t);
			}
		}
		return t;
	}

	

	public tNode rotateRight(tNode t)
	{
		
		int leftheight = 0;
		int leftrightheight= 0;
		if (t.left==null)
		{ leftheight = -1; }
		else {leftheight = t.left.height;}
		if (t.left.right==null)
		{ leftrightheight = -1; }
		else {leftrightheight= t.left.right.height;}
		
		tNode holder = t.left.right;
		t.left.right= t;
		tNode returner = t.left;
		t.left=holder;
		
		if(returner.left != null)
		{returner.left.height = leftheight;}
		
		returner.right.height = leftrightheight+1;
		
		if(returner.left==null || returner.right.height>returner.left.height)
		{ returner.height = returner.right.height+1;}
		else
		{ returner.height = returner.left.height+1;}
		
		return returner;
		
	}

	public tNode rotateLeft(tNode t)
	{		
		int rightheight = 0;
		int rightleftheight= 0;
		if (t.right==null)
		{ rightheight = -1; }
		else { rightheight = t.right.height;}
		if (t.right.left==null)
		{ rightleftheight = -1; }
		else {rightleftheight= t.right.left.height;}
		
		tNode holder = t.right.left;
		t.right.left= t;
		tNode returner = t.right;
		t.right=holder;

		if(returner.right != null)
		{returner.right.height = rightheight;}
		
		returner.left.height = rightleftheight+1;
		
		if(returner.right==null || returner.left.height>returner.right.height)
		{ returner.height = returner.left.height+1;}
		else
		{ returner.height = returner.right.height+1;}
		
		return returner;
		
	}

	public tNode find(String k)
	{
		return findhelper(root, k);
	}
	public tNode findhelper(tNode t, String k)
	{ 	
		if (t == null)
		{
			//System.out.print("KEY NOT FOUND: \""); System.out.print(k); System.out.print("\"");
			//System.out.println();
			return null; //new tNode (new Pair("BAD", "KEYNOTFOUND"),null,null); //NOT FOUND
		}
		else if (t.pair.key.compareTo(k) == 0 && t.deleted==false)
		{
			return t;
		}
		else if (t.pair.key.compareTo(k) > 0)
		{
			return findhelper(t.left, k);
		}
		else if (t.pair.key.compareTo(k) < 0)
		{
			return findhelper(t.right, k);
		}
		else
		{
			return null;
		}
	}

	public Object delete(String k)
	{
		return deletehelper(root, k);
	}
	public Object deletehelper(tNode t, String k)
	{	
		tNode found = findhelper(t, k);
		found.deleted = true;
		return found;
	}

}
