

public class SchemeSymbol extends SchemeObject {

	public String symbol;
	
	//
	
	public static boolean isValidNumber(String s) {
		//System.out.println("VALID CHECK");
		try {
		int i = Integer.parseInt(s);
		return s.length() > 0 && s.length() < 9;
		}
		catch (NumberFormatException nfe) {
		return false;
		}
		}
	
	public SchemeObject eval(AVLTree env)
	{
		if (isValidNumber(symbol))
		{
			//System.out.println("VALID PASS");
			return new SchemeNumber(Integer.parseInt(symbol));
		}
		else{
			AVLTree.tNode lookup = env.find(symbol);
			if (lookup==null)
			{
				System.out.print("KEY NOT FOUND: \""); System.out.print(symbol); System.out.print("\""); System.out.println();
				return this;}
			else{
				return(lookup.pair.obj);}}
	}
	//
	
	public SchemeSymbol(String symbol) {
		this.symbol = symbol;
	}

	public void print() {
		System.out.print(symbol);
	}
}
