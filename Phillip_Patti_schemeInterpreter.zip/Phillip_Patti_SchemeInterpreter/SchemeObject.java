

public abstract class SchemeObject {
	
	public SchemeObject() { }

	public abstract SchemeObject eval(AVLTree x);
	
	public void print() { }

	protected void output() { }
}
