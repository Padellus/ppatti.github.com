

public class SchemePair extends SchemeObject {

	public SchemeObject left;
	public SchemeObject right;
	
	public SchemePair(SchemeObject left, SchemeObject right) {
		this.left = left;
		this.right = right;
	}
	/*
	public SchemePair(SchemeObject left, SchemeObject right, boolean mapStatus) {
		this.left = left;
		this.right = right;
		this.map = mapStatus;
	}*/
	
	public void print() {
		System.out.print("(");
		this.output();
		System.out.print(")");
	}

	public SchemeObject eval(AVLTree env)
	{
		//System.out.println("PairEval HIT");
		SchemeObject lefty = left.eval(env);
		if(lefty instanceof SchemeMap)
		{
			//System.out.println("Found a map");
			SchemeObject bufferLeft = ((SchemePair)right).left;
			SchemeObject bufferRight = ((SchemePair)right).right;
			return ((SchemeMap)lefty).apply(new SchemePair(lefty,
					new SchemePair(bufferLeft.eval(env) , bufferRight.eval(env))));
		}
		
		SchemePair ret = new SchemePair( lefty, right.eval(env));
/*		if(ret.left instanceof SchemeMap)
		{
			//System.out.println("Call map");
			SchemeFunction buff = (SchemeFunction) ret.left;
			return buff.apply(ret);
		}*/
		if(ret.left instanceof SchemeFunction)
		{
			//System.out.println("Func HIT");
			SchemeFunction buff = (SchemeFunction) ret.left;
			return buff.apply(ret);
		}
/*		else if (ret.left instanceof SchemeFunction && env.map == true )
		{
			//SchemeFunction buff = (SchemeFunction) ret.left;
			env.passmap++;
			return ret;
		}*/
		return ret;
	}
	
	protected void output() {
		if (left instanceof SchemePair) {
			System.out.print("(");
			left.output();
			System.out.print(")");
		}
		else
			left.print();

		if(left instanceof SchemeSymbol && right instanceof SchemeSymbol) {
			System.out.print(" . ");
			right.print();
		}
		else if(right instanceof SchemePair) {
			System.out.print(" ");
			right.output();
		}
	}
}
