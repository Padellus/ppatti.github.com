

public class CloseParen extends Token{ }
