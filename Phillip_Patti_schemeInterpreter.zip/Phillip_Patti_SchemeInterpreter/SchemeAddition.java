
public class SchemeAddition extends SchemeFunction{

	int sum;
	public SchemeObject apply(SchemePair args)
	{
		//System.out.println("add apply called");
		sum = 0;
		SchemeObject next = ((SchemePair) args).right;
		if (((SchemePair)next).left instanceof SchemePair)
		{
			System.out.println("Error: Tried to apply add to a list!");
			return null;
		}
		return new SchemeNumber(additionHelper(next));
	}
	
	public int additionHelper(SchemeObject inp)
	{
		if(inp instanceof SchemeNull)
		{
			return sum;
		}
		else if(inp instanceof SchemePair)
		{
			SchemeObject buff= ((SchemePair) inp).left;
			SchemeNumber buff2= ((SchemeNumber) buff);
			sum+=buff2.n;
			SchemeObject buff3= ((SchemePair) inp).right;
			return (additionHelper(buff3));
		}
		/*
		else if(inp instanceof SchemeNumber)
		{
			sum+=((SchemeNumber) inp).n;
			return sum;
		}*/
		else
		{
			sum+=999999;
			System.out.println("ERROR IN ADDITION");
			return sum;
		}
	}
}
