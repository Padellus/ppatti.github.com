
	
public class StackNode {

	public Object data;
	public StackNode next;
	
	public StackNode(Object o, StackNode next) {
		this.data = o;
		this.next = next;
	}

	public StackNode(Object o) {
		this.data = o;
		this.next = null;
	}
}
