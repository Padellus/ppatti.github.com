
public class SchemeMap extends SchemeFunction{

	SchemeFunction fun;
	public SchemeObject apply(SchemePair args)
	{
		SchemeObject buff = args.right;
		SchemeObject buff2 = ((SchemePair)buff).left;
		fun= ((SchemeFunction) buff2);
		SchemeObject buff3 = ((SchemePair)buff).right;
		SchemeObject list = ((SchemePair)buff3).left;
		return mapHelper(list);
	}
	
	public SchemeObject mapHelper(SchemeObject inp)
	{
		if(inp instanceof SchemeNull)
		{
			return new SchemeNull();
		}
		else if(inp instanceof SchemePair)
		{
			SchemeObject buff= ((SchemePair) inp).left;
			//SchemeNumber buff2= ((SchemeNumber) buff);
			SchemePair buffpair = new SchemePair (buff , new SchemeNull());
			SchemePair buffpair2 = new SchemePair (fun, buffpair);
			SchemeObject buff3= ((SchemePair) inp).right;
			return( new SchemePair((fun.apply(buffpair2)) , (mapHelper(buff3)))) ;
		}
		else
		{
			System.out.println("ERROR IN MAP");
			return null;
		}
	}

}
