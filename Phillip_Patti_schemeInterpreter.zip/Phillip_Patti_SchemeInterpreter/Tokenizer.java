import java.io.*;

public class Tokenizer {

	// This implementation reads a line from input and stores the .split("\\s+")
	// strings in a String array.
	// It uses two indices to keep track of the parsing location:
	//	 curstring keeps track of which string in the array is being parsed
	//       index keeps track of parser position within the current string

	int index;
	int curstring;
	String[] strings;
	private BufferedReader input;

	public Tokenizer(InputStream inputstream) throws IOException {
		input = new BufferedReader(new InputStreamReader(inputstream));
		
		index = 0;
		curstring = 0;
		strings = new String[0];
	}

	// Parse and return the next token. If stored strings are exhausted, it deletes
	// them and reads a new line from input before continuing.
	public Token nextToken() throws IOException{
		// If at end of line, move to the next string
		try {
			if(index == strings[curstring].length()) {
				index = 0;
				curstring++;
			}
		}
		catch (ArrayIndexOutOfBoundsException e) {
			getLine();
		}

		if (curstring == strings.length)
			getLine();

		Token out = null;
		
		if (strings[curstring].charAt(index) == '(')
			out = new OpenParen();
		else if (strings[curstring].charAt(index) == ')')
			out = new CloseParen();
		else if (strings[curstring].charAt(index) == '.')
			out = new Period();
		else {
			int start = index;
			
			// Step through until at the end of the string or at another token
			while (index < strings[curstring].length() && strings[curstring].charAt(index) != '(' && 
				strings[curstring].charAt(index) != ')' && strings[curstring].charAt(index) != '.')
				index++;
			
			out = new TokenSymbol(strings[curstring].substring(start,index));

			index--; // index has moved past the end of this string, so backstep by one.
		}
		
		index++;
		return out;
	}

	private void getLine() throws IOException {
		System.out.print("eval> ");
		strings = input.readLine().split("\\s+");

		// Continue to query for input until a non-empty line is reached
		while (strings.length == 1 && strings[0].length() == 0) {
			System.out.print("eval> ");
			strings = input.readLine().split("\\s+");
		}

		// Reset pointers
		index = 0;
		curstring = 0;		
	}
}
