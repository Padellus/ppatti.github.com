
public class Pair {

	public String key;
	public SchemeObject obj;
	public Pair(String k, SchemeObject o)
	{key = k; obj = o;} 
}
