
public class SchemeMultiplication extends SchemeFunction{
	int prod;
	public SchemeObject apply(SchemePair args)
	{
		prod = 1;
		return new SchemeNumber(multHelper(args.right));
	}
	
	public int multHelper(SchemeObject inp)
	{
		if(inp instanceof SchemeNull)
		{
			return prod;
		}
		else if(inp instanceof SchemePair)
		{
			SchemeObject buff= ((SchemePair) inp).left;
			SchemeNumber buff2= ((SchemeNumber) buff);
			prod*= buff2.n;
			SchemeObject buff3= ((SchemePair) inp).right;
			return (multHelper(buff3));
		}
		else
		{
			prod*=0;
			System.out.println("ERROR IN MULTIPLICATION");
			return prod;
		}
	}
}
