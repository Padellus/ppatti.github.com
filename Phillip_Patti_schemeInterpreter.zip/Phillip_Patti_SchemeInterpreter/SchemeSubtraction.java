
public class SchemeSubtraction extends SchemeFunction{
	int sum;
	public SchemeObject apply(SchemePair args)
	{
		sum = 0;
		SchemeObject next = ((SchemePair) args).right;
		if (((SchemePair)next).left instanceof SchemePair)
		{
			System.out.println("Error: Tried to apply subtract to a list!");
			return null;
		}
		if (next instanceof SchemePair && ((SchemePair) next).right instanceof SchemeNull)
		{
			SchemeObject buff = ((SchemePair)next).left;
			return new SchemeNumber((sum - ((SchemeNumber)buff).n));
		}
		else if( next instanceof SchemeNull)
		{
			return new SchemeNumber(0);
		}
		else
		{
			SchemeObject buff = ((SchemePair)next).left;
			sum += ((SchemeNumber)buff).n;
			SchemeObject buff2 = ((SchemePair)next).right;
			return new SchemeNumber(subHelper(buff2));
		}
	}

	public int subHelper(SchemeObject inp)
	{
		if(inp instanceof SchemeNull)
		{
			return sum;
		}
		else if(inp instanceof SchemePair)
		{
			SchemeObject buff= ((SchemePair) inp).left;
			SchemeNumber buff2= ((SchemeNumber) buff);
			sum-=buff2.n;
			SchemeObject buff3= ((SchemePair) inp).right;
			return (subHelper(buff3));
		}
		else
		{
			sum-=999999;
			System.out.println("ERROR IN SUBTRACTION");
			return sum;
		}
	}
}

