

public class OpenParen extends Token { }
