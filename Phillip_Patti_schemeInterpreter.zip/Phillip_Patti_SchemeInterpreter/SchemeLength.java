
public class SchemeLength extends SchemeFunction{
	int sum;
	public SchemeObject apply(SchemePair args)
	{
		sum = 0;
		SchemeObject buff = args.right;
		if (buff instanceof SchemeNull)
		{
			System.out.println("Error: call length on a list");
			return null;
		}
		return new SchemeNumber(lengHelper(((SchemePair)buff).left));
	}

	public int lengHelper(SchemeObject inp)
	{
		if(inp instanceof SchemeNull)
		{
			return sum;
		}
		else if(inp instanceof SchemePair)
		{
			//System.out.println("Length+1");
			sum+= 1 ;
			SchemeObject buff3= ((SchemePair) inp).right;
			return (lengHelper(buff3));
		}
		else
		{
			sum+=999999;
			System.out.println("ERROR IN LENGTH");
			return sum;
		}
	}
}
