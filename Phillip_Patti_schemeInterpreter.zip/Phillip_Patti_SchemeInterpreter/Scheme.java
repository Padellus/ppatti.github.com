import java.io.*;

public class Scheme {

	public static void main(String[] args) {
		/*
		Parser parser;
		SchemeObject value;

		// Instantiate parser with a Tokenizer that processes System.in
		try {
			Tokenizer T = new Tokenizer(System.in);
			parser = new Parser(T);
		}
		catch (IOException e) {
			System.out.println("An error occured while attempting to read from System Input.");
			return;
		}

		// Loop forever: Get next SchemeObject and print it on its own line.
		while(true) {
			try {
				value = parser.nextObject();
			}
			catch (IOException e) {
				System.out.println("An error occured while attempting to read from System Input.");
				return;
			}

			value.print();
			System.out.println();
		}*/
	/*
		AVLTree MyDictionary = new AVLTree();
		Pair p1 = new Pair("x", "100");
		Pair p2 = new Pair("y", "200");
		Pair p3 = new Pair("z", "300");
		Pair p4 = new Pair("+", "99");
		Pair p5 = new Pair("yo", "gabbagabba");
		Pair p6 = new Pair("sup", "dawg");
		Pair p7 = new Pair("howdy", "ho");
		Pair p8 = new Pair("yippee", "kiyay");
		MyDictionary.add(p1); MyDictionary.add(p2); 
		MyDictionary.add(p3); MyDictionary.add(p4);
		MyDictionary.add(p5); MyDictionary.add(p6);
		MyDictionary.add(p7); MyDictionary.add(p8);
	*/	
		AVLTree MyDictionary = new AVLTree();
		Pair p1 = new Pair("+", new SchemeAddition());
		Pair p2 = new Pair("-", new SchemeSubtraction());
		Pair p3 = new Pair("*", new SchemeMultiplication());
		Pair p4 = new Pair("length", new SchemeLength());
		Pair p5 = new Pair("list", new SchemeList());
		Pair p6 = new Pair("map", new SchemeMap());
		Pair p7 = new Pair("x", new SchemeNumber(100));
		Pair p8 = new Pair("y", new SchemeNumber(200));
		Pair p9 = new Pair("z", new SchemeNumber(300));
		MyDictionary.add(p1); MyDictionary.add(p2); 
		MyDictionary.add(p3); MyDictionary.add(p4);
		MyDictionary.add(p5); MyDictionary.add(p6);
		MyDictionary.add(p7); MyDictionary.add(p8); MyDictionary.add(p9);
		System.out.println("Dictionary Created with keys: +, -, *, length, list, map, x, y, z.");
		Parser parser;
		SchemeObject value;

		// Instantiate parser with a Tokenizer that processes System.in
		try {
			Tokenizer T = new Tokenizer(System.in);
			parser = new Parser(T);
		}
		catch (IOException e) {
			System.out.println("An error occured while attempting to read from System Input.");
			return;
		}

		// Loop forever: Get next SchemeObject and print it on its own line.
		while(true) {
			try {
				value = parser.nextObject();
			}
			catch (IOException e) {
				System.out.println("An error occured while attempting to read from System Input.");
				return;
			}

			SchemeObject evald = value.eval(MyDictionary);
			if(evald != null)
			{
				evald.print();
			}
			//value.eval(MyDictionary).print();
			System.out.println();

	}
	
} }
