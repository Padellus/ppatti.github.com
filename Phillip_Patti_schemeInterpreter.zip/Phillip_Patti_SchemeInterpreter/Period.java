

public class Period extends Token { }
