

public abstract class Token { }
