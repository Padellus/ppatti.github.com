
public class SchemeList extends SchemeFunction{

	public SchemeObject apply(SchemePair args)
	{
		return (args.right);
	}
}
