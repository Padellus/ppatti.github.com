

public class TokenSymbol extends Token {

	private String value;
	
	public TokenSymbol(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}
