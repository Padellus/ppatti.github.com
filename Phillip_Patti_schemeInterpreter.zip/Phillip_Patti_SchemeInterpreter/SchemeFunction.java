
public abstract class SchemeFunction extends SchemeObject{

	
	abstract public SchemeObject apply(SchemePair args);
	public SchemeFunction eval(AVLTree env)
	{
		return this;
	}
}
