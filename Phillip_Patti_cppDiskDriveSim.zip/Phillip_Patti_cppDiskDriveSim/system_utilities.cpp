#include "system_utilities.h"
#include "definitions.h"
#include "machines.h"
#include "disk_drive.h"
#include <iostream>
#include <fstream>
#include <cstdlib>

#include <string>
#include <iomanip>
using namespace std;

computer* network[MAX_NETWORK_NODES];

class commandElement
{
    public:
    commandElement(char*, int);
    char* cmdString;
    int intToken;
};

commandElement::commandElement(char* s, int tok)
{
    int len = strlen(s);
    cmdString = (char*) malloc (len + 1);
    memcpy(cmdString, s, len);
    cmdString[len] = 0;
    intToken = tok;
}

commandElement* commandList[NUMBER_OF_COMMANDS];

void fillCommandList()
{
    commandList[1] = new commandElement("system_status", SYSTEM_STATUS);
    commandList[2] = new commandElement("halt", HALT);
    commandList[3] = new commandElement("add_network_node", ADD_NETWORK_NODE);
    commandList[4] = new commandElement("delete_network_node", DELETE_NETWORK_NODE);
    commandList[5] = new commandElement("create_file", CREATE_FILE);
    commandList[6] = new commandElement("ls", LS);
    commandList[7] = new commandElement("delete_files", DELETE_FILES);
    commandList[8] = new commandElement("print_files", PRINT_FILES);
    commandList[9] = new commandElement("transfer_file", TRANSFER_FILE);
    commandList[7]->cmdString[12] =19;
}

int getCommandNumber(char* s)
{
    for (int jj=1; jj<=NUMBER_OF_COMMANDS; jj++)
        {
            if(strcmp(s, (commandList[jj])->cmdString) == 0)
                {
                    return commandList[jj]->intToken;
                }
            if(jj == NUMBER_OF_COMMANDS)
                {
                    return UNDEFINED_COMMAND;
                }
        }
    return 0;
}

int parseCommandLine(char* line, char* tokens[])
{
    int token_count=0;
    int count = 0;
    char terminator = 32;
    int beginning = 0;
    bool insidequotes = 0;
    do
    {
        count++;
        if (line[count] == terminator || line[count] == 0)
        {
            int token_length = count - beginning;
            tokens[token_count] = (char *) malloc( token_length );
            for (int i=beginning; i<token_length; i++)
            {
                if (line[i] == 19)
                {
                    token_length = token_length-1;
                }
            }
            if (line[count-1] == 13 || line[count] == 19)
            {
                token_length = token_length-1;
            }
            memset( tokens[token_count], 0, token_length);
            memcpy( tokens[token_count], line+beginning, token_length);
            token_count++;
            if (insidequotes == 1)
            {
                count++;
                insidequotes = 0;
            }
        }
        if (line[count] == 34)
        {
            beginning = count+1;
            terminator = 34;
            insidequotes = 1;
        }
        if (line[count] == 32 && insidequotes == 0)
        {
            while (line[count+1] == 32)
            {
                count++;
            }
            beginning = count+1;
            terminator = 32;
        }
    }
    while (line[count] != 0);
    return token_count;
}

int stringToInt (char* stringInp)
{
    int sum = 0;
    int multiplier = 1;
    int length = strlen(stringInp);
    for (int ii = 0 ; ii<length ; ii++)
    {
        multiplier = 1;
        for (int jj = length; jj>ii+1; jj--)
        {
            multiplier = (multiplier * 10);
        }
        sum = sum + ( multiplier * ((int)stringInp[ii]-48));
    }
    return sum;
}

void add_network_node(char* tokens[])
{
    if( strcmp(tokens[1], "PC") == 0)
    {
        int freespot = -1;
        for( int ii = MAX_NETWORK_NODES; ii>= 0; ii-- )
        {
            if(network[ii] == 0)
            {
                freespot = ii;
            }
        }
        if(freespot == -1)
        {
            cout << "NETWORK NODES AT MAXIMUM!!!" << endl;
        }
        else
        {
            network[freespot] = new PC(tokens[2], stringToInt(tokens[3]), tokens[4]);
            cout << "PC NODE CREATED" << endl;
        }
    }
    else if( strcmp(tokens[1], "printer") == 0)
    {
        int freespot = -1;
        for( int ii = MAX_NETWORK_NODES; ii>= 0; ii-- )
        {
            if(network[ii] == 0)
            {
                freespot = ii;
            }
        }
        if(freespot == -1)
        {
            cout << "NETWORK NODES AT MAXIMUM!!!" << endl;
        }
        else
        {
            network[freespot] = new printer(tokens[2], stringToInt(tokens[3]), stringToInt(tokens[4]));
            cout << "PRINTER NODE CREATED" << endl;
        }
    }
    else if( strcmp(tokens[1], "server") == 0)
    {
        int freespot = -1;
        for( int ii = MAX_NETWORK_NODES; ii>= 0; ii-- )
        {
            if(network[ii] == 0)
            {
                freespot = ii;
            }
        }
        if(freespot == -1)
        {
            cout << "NETWORK NODES AT MAXIMUM!!! No node created." << endl;
        }
        else
        {
            network[freespot] = new server(tokens[2], stringToInt(tokens[3]), tokens[4]);
            cout << "SERVER NODE CREATED" << endl;
        }
    }
    else
    {
        cout << "Network node type \"" << tokens[1] << "\" unknown. No node created." << endl;
    }
}

void system_status()
{
    for(int ii=0; ii<MAX_NETWORK_NODES; ii++)
    {
        if(network[ii] == 0)
        {
        }
        else
        {
            network[ii]->print();
            cout << "\n" ;
        }
    }
}

int compFinder(char* tokens[])
{
    for(int ii=0; ii<MAX_NETWORK_NODES; ii++)
        {
            if(network[ii] == 0)
            {
            }
            else
            {
                if(network[ii]->isThisMyName(tokens[1]))
                {
                    return ii;
                }
            }
        }
        return -1;
}

void delete_network_node(char* tokens[])
{
    int targetLocation = compFinder(tokens);
    if(targetLocation == -1)
    {
        cout << "Target: \"" << tokens[1] << "\" not found. No node was deleted" << endl;
    }
    else
    {
        delete network[targetLocation];
        network[targetLocation]= 0;
        cout << "Target: \"" << tokens[1] << "\" deleted." << endl;
    }
}

void create_file(char* tokens[])
{
    int location = compFinder(tokens);
    if(location ==-1)
    {
        cout<<"ERROR: Couldn't find computer \""<<tokens[1]<<"\" to create file on, file not created!!!"<<endl;
    }
    else
    {
        network[location]->createFile(tokens[2], stringToInt(tokens[3]));
    }
}

void ls(char* tokens[])
{
    int location = compFinder(tokens);
    if(location ==-1)
    {
        cout<<"ERROR: Couldn't find computer \""<<tokens[1]<<"\" to LS on!!!"<<endl;
    }
    else
    {
        cerr<< "Computer found!" <<endl;
        network[location]->printDirectory();
    }
}

int wait()
{
    char answer = 'n';
    while (answer != 'y')
    {cout<< "\nProgram is waiting so you can analyze status. Continue? y/n" << endl;
    cin >> answer ;}
    return 0;
}
