/*

Author:     Phillip Patti
Contact:    ppatti@u.northwestern.edu

    The disk_drive class now implements formatDiskDrive which allocates the first
    few blocks of the drive to store the filedescriptors. The machines class can
    now create new files (a system utility) which creates a file descriptor and
    stores it in the appropriate spot on the diskdrive. Also, the system utility
    LS is implemented which shows the listing of file descriptors for a machine.

*/

using namespace std;
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>

#include <iomanip>
#include "system_utilities.h"
#include "definitions.h"

ifstream inp("p7input.txt", ios::in );

int main()
{
    if (!inp)
    {
        cerr << "File could not be opened.\n";
        exit(1);
    }
    char* lastCmd="start";
    fillCommandList();
    while(strcmp(lastCmd, "halt"))
    {
        char* tokens[MAX_TOKENS_ON_A_LINE];
        char* line = (char *)malloc ( MAX_CMD_LINE_LENGTH +1);
        memset(line, 0, MAX_CMD_LINE_LENGTH+1);
        inp.getline(line, MAX_CMD_LINE_LENGTH);
        int tokens_in_line = parseCommandLine(line, tokens);
        lastCmd = tokens[0];

        switch(getCommandNumber(lastCmd))
        {
            case SYSTEM_STATUS:
            cout << "Recognized command to check system status." << endl;
            system_status();
            wait();
            break;
            case HALT:
            cout << "Recognized halt command" << endl;
            break;
            case ADD_NETWORK_NODE:
            cout << "Recognized command to add a new node to the network." << endl;
            add_network_node(tokens);
            break;
            case DELETE_NETWORK_NODE:
            cout << "Recognized command to delete a node from the network." << endl;
            delete_network_node(tokens);
            break;
            case CREATE_FILE:
            cout << "Recognized command to create a new file." << endl;
            create_file(tokens);
            break;
            case LS:
            cout << "Recognized command to LS." << endl;
            ls(tokens);
            break;
            case DELETE_FILES:
            cout << "Recognized command to delete files." << endl;
            break;
            case PRINT_FILES:
            cout << "Recognized command to print files." << endl;
            break;
            case TRANSFER_FILE:
            cout << "Recognized command to transfer files." << endl;
            break;
            case UNDEFINED_COMMAND:
            cout << "Command: \"" << tokens[0] << "\" not recognized." << endl;
            break;
        }


        for (int jj=0; jj<tokens_in_line; jj++)
        {
            cout << "  TOKEN " << jj+1 << ": " << tokens[jj] << endl;
        }

        cout << line << endl << endl;

    }
    return 0;
}
