#ifndef SYSTEM_UTILITIES_H_INCLUDED
#define SYSTEM_UTILITIES_H_INCLUDED


int parseCommandLine(char*, char* []);
void fillCommandList();
int getCommandNumber(char*);
int stringToInt(char*);
void add_network_node(char* []);
void system_status();
int compFinder(char* []);
void delete_network_node(char* []);
void create_file(char* []);
void ls(char* []);
int wait();

#endif // SYSTEM_UTILITIES_H_INCLUDED
