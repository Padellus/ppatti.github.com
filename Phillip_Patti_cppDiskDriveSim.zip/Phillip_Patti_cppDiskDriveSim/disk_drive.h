#ifndef DISK_DRIVE_H_INCLUDED
#define DISK_DRIVE_H_INCLUDED


class diskDrive
{
public:
    diskDrive( int );
    ~diskDrive(); // destructor
    void print();
    void allocateBlock( int );
    void freeBlock( int );
    int isBlockFree( int );

    void storeBlock( unsigned char* , int );
    void retrieveBlock ( unsigned char*, int );
    void formatDrive( int );

private:
    int blockCount;
    unsigned char* bitmap;
    char* spacePnter;
};

#endif // DISK_DRIVE_H_INCLUDED
