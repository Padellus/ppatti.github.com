
#include <iostream>
#include <iomanip>

#include <cstdlib>
#include "disk_drive.h"
#include "definitions.h"

using namespace std;

diskDrive::diskDrive( int byteCountInp ) // diskDrive constructor
{
    blockCount = (byteCountInp + 7) / 8;
    int bitmapSize = (blockCount + 7) / 8;
    spacePnter = (char*) malloc( blockCount*64 );
    bitmap = (unsigned char*) malloc( bitmapSize );
    memset( bitmap, 0, bitmapSize );
}

diskDrive::~diskDrive()
{
    free( spacePnter );
    free( bitmap );
}

void diskDrive::print()
{
    int bitpos = 0;
    unsigned char bytevalue;
    cout << "The number of blocks: " << blockCount << endl;   // error catchers
    cout << "The bitmap size: " << (blockCount+7)/8 << " bytes" << endl;
    cout << "The bitmap by byte in hexadecimal:" << endl;
    bitpos = 0;
    for (int ii=0; ii<(blockCount+7)/8; ii++)   // bitmap by bytes in hexadecimal
    {
        if ((bitpos)%4 == 0 && bitpos!= 0)
        {cout << "\n";}
        bytevalue = (bitmap[ii] * 0x0202020202ULL & 0x010884422010ULL) % 1023;
        cout << hex << setw(6) << "byte " << setw(2) << bitpos << ": " << setw(3) << (int)bytevalue << "  " << dec;
        bitpos++;
    }
    cout << "\n";
}

void diskDrive::allocateBlock( int blockNum )
{
    int bytepos = ((blockNum+8)/8) - 1;
    int bitpos  = blockNum%8;
    unsigned MASK = 1;
    MASK = MASK << bitpos;
    if (blockNum < 0)
        cout<<"\nERROR: Tried to allocate block "<< blockNum << " which is a negative-value located block!!!"<< endl;
    else if (blockNum > blockCount)
        cout<<"\nERROR: Tried to allocate block "<< blockNum << " which is outside of allotted block count!!!" << endl;
    else if (bitmap[bytepos] & MASK)
        cout<<"\nERROR: Tried to allocate block "<< blockNum << " which is already allocated!!!" << endl;
    else
        bitmap[bytepos]= (bitmap[bytepos] | MASK);
}

void diskDrive::freeBlock( int blockNum )
{
    int bytepos = ((blockNum+8)/8) - 1;
    int bitpos  = blockNum%8;
    unsigned MASK = 1;
    MASK = MASK << bitpos;
    if (blockNum < 0)
        cout<<"\nERROR: Tried to free block "<< blockNum << " which is a negative-value located block!!!"<< endl;
    else if (blockNum > blockCount)
        cout<<"\nERROR: Tried to free block "<< blockNum << " which is outside of allotted block count!!!" << endl;
    else
        bitmap[bytepos]= (bitmap[bytepos] & ~(MASK));
}

int diskDrive::isBlockFree( int blockNum )
{
    int bytepos = ((blockNum+8)/8) - 1;
    int bitpos  = blockNum%8;
    unsigned MASK = 1;
    MASK = MASK << bitpos;
    if (blockNum < 0)
    {
        cout<<"\nERROR: Tried to check block "<< blockNum << " which is a negative-value located block!!!"<< endl;
        return 0;
    }
    else if (blockNum > blockCount)
    {
        cout<<"\nERROR: Tried to check block "<< blockNum << " which is outside of allotted block count!!!" << endl;
        return 0;
    }
    else
    {
        if (bitmap[bytepos] & MASK)
            return 1;
        else
            return 0;
    }
}

void diskDrive::storeBlock( unsigned char* d, int blk)
{
    if(blk < blockCount)
    {
        memcpy( spacePnter+(blk*64), d , 64 );
        cout << "BLOCK STORED" << endl;
    }
    else
    {
        cout<<"\nERROR: Tried to store in block "<<blk<<" which is outside of the allotted block count!!!"<<endl;
    }
}


void diskDrive::retrieveBlock ( unsigned char* d, int blk)
{
    if(blk < blockCount)
    {
        memcpy( d, spacePnter+(blk*64), 64);
    }
    else if (blk >= blockCount || blk<0)
    {
        cout<<"\nERROR: Tried to retrieve block "<<blk<<" which is outside of the allotted block count!!!"<<endl;
    }
    else
    {
        cout<<"\nERROR: Tried to retrieve block "<<blk<<" which is empty!!!"<<endl;
    }
}

void diskDrive::formatDrive( int maxFiles)
{
    fileDescriptor nonfiledesc;

    memset(nonfiledesc.fileName, 94, 8);

    nonfiledesc.fileLength=-1;
    nonfiledesc.NumberOfFirstBlock=0;
    for(int blk=0 ; blk<blockCount ; blk++)
    {
        freeBlock(blk);
    }

    if(maxFiles == 8)
    {
        allocateBlock(0); allocateBlock(1);
        for(int ii=0; ii<8 ; ii++)
        {
            memcpy( spacePnter+(ii*16), &nonfiledesc, 16);
        }

    }

    if(maxFiles == 16)
    {
        allocateBlock(0); allocateBlock(1); allocateBlock(2); allocateBlock(3);
        for(int ii=0 ; ii<16 ; ii++)
        {
            memcpy( spacePnter+(ii*16), &nonfiledesc, 16);
        }
    }
}
