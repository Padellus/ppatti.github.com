#ifndef MACHINES_H_INCLUDED
#define MACHINES_H_INCLUDED

#include <string>

#include "disk_drive.h"
#include "definitions.h"

using namespace std;

class computer
{
public:
    computer( char* , int, int );
    virtual ~computer();
    virtual void print();
    int isThisMyName(char *);

    int maximum_number_of_files;

    char compName[21];

    void createFile( char*, int);
    void printDirectory();

private:
    diskDrive* diskDrivePntr;

protected:
    int findFreeFileDescriptor();
    void getFileDescriptor(int, fileDescriptor*);
    void putFileDescriptor(int, fileDescriptor*);
};

class PC: public computer
{
public:
    PC( char*, int, char* );
    virtual void print();

    char compName[21];
    diskDrive* diskDrivePntr;
    char ownerName[31];
};

class server: public computer
{
public:
    server( char*, int, char* );
    virtual void print();

    char compName[21];
    diskDrive* diskDrivePntr;
    char location[15];
};

class printer: public computer
{
public:
    printer( char*, int, int );
    virtual void print();

    char compName[21];
    diskDrive* diskDrivePntr;
    int printerCount;
};

#endif // MACHINES_H_INCLUDED
