
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <string>


#include "machines.h"
#include "disk_drive.h"
#include "definitions.h"

using namespace std;

computer::computer( char* compNameInp ,int byteCountInp, int maxFiles)
{
    for (int i=0; i<=21; i++)
    {
    compName[i] = compNameInp[i];
    }
    if (byteCountInp < 128) // catches small drives and makes them at least 128
        {diskDrivePntr = new diskDrive(128);}  // creates new diskDrive object
    else
        {diskDrivePntr = new diskDrive(byteCountInp);}

    diskDrivePntr->formatDrive(maxFiles);
}

computer::~computer()
{
    delete(diskDrivePntr);
}


void computer::print()
{
    cout << "The computer's name is:  " << compName << endl;
    diskDrivePntr->print();
}

int computer::isThisMyName(char* n)
{
    if(strcmp(compName, n) == 0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

void computer::createFile( char* n, int len)
{
   int freespot = findFreeFileDescriptor();

   if(freespot==-1)
   {
       cout<<"\nERROR: There are no free file descriptors, file not created!!!"<<endl;
   }
   else
   {
       cout<< "File created in storage spot: "<< freespot<<endl;
       fileDescriptor* newfile=(fileDescriptor*) malloc(16);
       for(int ii=0; ii<8; ii++)
       {
            newfile->fileName[ii]= (char)n[ii];
       }

       newfile->fileLength = len;
       newfile->NumberOfFirstBlock = 0;
       putFileDescriptor(freespot, newfile);
   }
}

void computer::printDirectory()
{
    fileDescriptor* filedesc= (fileDescriptor*) malloc(16);
    for(int ii=0; ii<8; ii++)
    {
        filedesc->fileName[ii]= 0;
    }
    filedesc->fileLength = 0;
    filedesc->NumberOfFirstBlock = 0;
    cout<< "Directory of " << compName <<":"<< endl;
    for(int ii=0 ; ii<maximum_number_of_files ; ii++)
    {
        getFileDescriptor(ii, filedesc);
        if(filedesc->fileLength==-1)
        {
            cout<<"File Entry "<<ii<<"- not in use"<<endl;
        }
        else
        {
            cout<<"File Entry "<<ii<<"- file name = "<<filedesc->fileName<<", length = "<<filedesc->fileLength<<", first block on disk = "<<filedesc->NumberOfFirstBlock<<endl;
        }
    }
}

int computer::findFreeFileDescriptor()
{
    fileDescriptor holder;
    for( int ii=0 ; ii< maximum_number_of_files ; ii++)
    {
        getFileDescriptor( ii, &holder);
        if(holder.fileLength == -1)
        {
                return ii;
        }
    }
    return -1;
}


void computer::getFileDescriptor( int n, fileDescriptor* fd)
{
    unsigned char* blockbuffer;
    blockbuffer= (unsigned char*) malloc( 64 );
    int* intbuff; //= (int*) malloc(4);
    memset(blockbuffer, 51, 64);

    memcpy( (void*)intbuff, (void*)(blockbuffer+8+((n%4)*16)), 4);
    //memcpy( blockbuffer, diskDrivePntr->spacePnter+((n/4)*64), 64);
    diskDrivePntr->retrieveBlock( blockbuffer, (n/4) );

    memcpy( (void*)fd->fileName,(void*)(blockbuffer+((n%4)*16)), 8);
    //cout << "before int: " << blockbuffer[8] << blockbuffer[9] << endl;
    memcpy( (void*)intbuff, (void*)(blockbuffer+8+((n%4)*16)), 4);
    fd->fileLength = *intbuff;
    memcpy( (void*)intbuff, (void*)(blockbuffer+12+((n%4)*16)), 4);
    fd->NumberOfFirstBlock = *intbuff;
}

void computer::putFileDescriptor( int n, fileDescriptor* fd)
{
    unsigned char* blockbuffer ;
    blockbuffer = (unsigned char*) malloc( 64 );
    int* intbuff = &(fd->fileLength);
    diskDrivePntr->retrieveBlock( blockbuffer, n/4 );
    memcpy( (void*)(blockbuffer+((n%4)*16)), fd->fileName, 8);
    memcpy( (void*)(blockbuffer+8+((n%4)*16)), intbuff, 4);
    intbuff=&(fd->NumberOfFirstBlock);
    memcpy( (void*)(blockbuffer+12+((n%4)*16)), intbuff, 4);
    diskDrivePntr->storeBlock( blockbuffer, n/4 );
}

PC::PC( char* compNameInp ,int byteCountInp, char* ownerNameInp ):computer( compNameInp, byteCountInp, 8 )
{
    maximum_number_of_files = 8;
    for (int i=0; i<=31; i++)
    {
    ownerName[i] = ownerNameInp[i];
    }
}

void PC::print()
{
    computer::print();
    cout << "The owner of the PC is: " << ownerName << endl;
}

printer::printer( char* compNameInp ,int byteCountInp, int printerCountInp ):computer( compNameInp, byteCountInp, 16 )
{
    maximum_number_of_files = 16;
    printerCount = printerCountInp;
}

void printer::print()
{
    computer::print();
    cout << "The printer count is: " << printerCount << endl;
}

server::server( char* compNameInp ,int byteCountInp, char* locationInp ):computer( compNameInp, byteCountInp, 16 )
{
    maximum_number_of_files = 16;
    for (int i=0; i<=15; i++)
    {
    location[i] = locationInp[i];
    }
}

void server::print()
{
    computer::print();
    cout << "The location of the server is: " << location << endl;
}



