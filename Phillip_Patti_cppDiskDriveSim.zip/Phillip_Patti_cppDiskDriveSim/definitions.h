#ifndef DEFINITIONS_H_INCLUDED
#define DEFINITIONS_H_INCLUDED

const int MAX_CMD_LINE_LENGTH =255;
const int MAX_TOKENS_ON_A_LINE =10;
const int MAX_NETWORK_NODES =10;

const int NUMBER_OF_COMMANDS =9;
const int SYSTEM_STATUS =50;
const int HALT =51;
const int ADD_NETWORK_NODE =60;
const int DELETE_NETWORK_NODE =61;
const int CREATE_FILE =70;
const int LS =71;
const int DELETE_FILES =72;
const int PRINT_FILES =73;
const int TRANSFER_FILE =80;
const int UNDEFINED_COMMAND =99;


struct fileDescriptor
{
    char fileName[8];
    int fileLength;
    int NumberOfFirstBlock;
};


#endif // DEFINITIONS_H_INCLUDED
